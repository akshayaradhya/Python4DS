#!/bin/bash

wget https://raw.githubusercontent.com/apache/spark/master/data/mllib/kmeans_data.txt 

wget https://raw.githubusercontent.com/apache/spark/master/data/mllib/sample_lda_data.txt

wget https://raw.githubusercontent.com/apache/spark/master/data/mllib/sample_svm_data.txt

wget https://dl.dropboxusercontent.com/u/9448094/Datasets/District%20Data%20Labs/Spark%20Workshop/DBLP.tgz

wget https://dl.dropboxusercontent.com/u/9448094/Datasets/District%20Data%20Labs/Spark%20Workshop/ontime.zip

#wget https://dl.dropboxusercontent.com/u/9448094/Datasets/District%20Data%20Labs/Spark%20Workshop/shopping.tgz

wget https://dl.dropboxusercontent.com/u/9448094/Datasets/District%20Data%20Labs/Spark%20Workshop/tolstoy.txt.gz

wget https://dl.dropboxusercontent.com/u/9448094/Datasets/District%20Data%20Labs/Spark%20Workshop/winequality.tgz

wget https://dl.dropboxusercontent.com/u/9448094/Datasets/District%20Data%20Labs/Spark%20Workshop/olympics.tgz